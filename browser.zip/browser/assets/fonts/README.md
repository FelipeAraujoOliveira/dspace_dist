# Supported font formats

DSpace supports EOT, TTF, OTF, SVG, WOFF and WOFF2 fonts. 
